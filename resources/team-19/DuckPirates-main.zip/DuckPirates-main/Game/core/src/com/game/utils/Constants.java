package com.game.utils;

public final class Constants {
	
	public static final float PPM = 64f;
	public static final float SCALE = 2.0f;
}
